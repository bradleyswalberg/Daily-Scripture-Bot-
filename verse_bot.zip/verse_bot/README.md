# Daily Verse Bot

Sends one verse about Jesus Christ from the Book of Mormon to a Discord
channel every day, along with a short note on how it applies to you.

## Files
- `verses.json` - the 30 verses and notes
- `daily_verse_bot.py` - picks today's verse and sends it
- `.github/workflows/daily_verse.yml` - runs the script automatically every day
- `requirements.txt` - the one package this needs (`requests`)

## One-time setup
1. Create a Discord webhook in your server.
   Server Settings -> Integrations -> Webhooks -> New Webhook -> Copy URL.
2. Push this folder to a GitHub repo.
3. In the repo, go to Settings -> Secrets and variables -> Actions -> New repository secret.
   Name it `DISCORD_WEBHOOK_URL` and paste the webhook URL as the value.
4. That's it. GitHub Actions will run the script daily and post to Discord.

## Testing it yourself first
Before relying on GitHub Actions, you can run it locally:
```
export DISCORD_WEBHOOK_URL="your-url-here"
pip install -r requirements.txt
python daily_verse_bot.py
```
If a message shows up in your Discord channel, it works.
